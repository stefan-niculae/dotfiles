# Docker-compose plugin for oh my zsh

A copy of the completion script from the [docker-compose](1) git repo.

[1]:[https://github.com/docker/compose/blob/master/contrib/completion/zsh/_docker-compose]
